-Extract contents to root of USB folder

-Do the same with contents of APPS folder
	You will see:
		usb:/APPS
		    |----/APPFOLDER1
		    |----/APPFOLDER2
		    etc...
				


On PS2 if you wish to move files to memory card, 

1) Use wLE ISR Exfat and copy app from mass:/APPS/APP_I_WANT

2) navigate back to root of memcard

3) mcpaste chosen folder back to root of memcard